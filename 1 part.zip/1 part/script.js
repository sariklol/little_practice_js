var name = prompt("Введите свое имя");
console.log("Меня зовут " + name);
alert(name)

var age = prompt("Введите свой возраст");
console.log("Мне " + age + " лет");
alert(age)

var exc1 = prompt("Решите пример: 60 + 9 = ?");
console.log("Exc1: 60 + 9 = 69 " + " Ваш ответ: " + exc1);
alert(exc1)

var exc2 = prompt("Решите пример: 1000 - 7 = ?");
console.log("Exc2: 1000 - 7 = 993 " + " Ваш ответ: " + exc2)
alert(exc2)

var exc3 = prompt("Решите пример: 6 * 6 = ?")
console.log("Exc3: 6 * 6 = 36 " + " Ваш ответ: " + exc3)
alert(exc3)

var exc4 = prompt("Решите пример: 32 / 4 = ?")
console.log("Exc4: 32 / 4 = 8  " + "Ваш ответ: " + exc4);
alert(exc4)

var exc5 = prompt("Решите пример: 91 % 2 = ?")
console.log("Exc5: 91 % 2 = 1  " + "Ваш ответ: " + exc5);
alert(exc5)

var final = "Откройте консоль что бы увидеть результаты."
alert(final)
